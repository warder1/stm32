
#include <stm32f4xx.h>

void _CheckUpdateTouch(void);
void Touch_calibration(void);

