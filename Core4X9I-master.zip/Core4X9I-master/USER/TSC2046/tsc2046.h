#ifndef 	_TSC2046_H_
#define 	_TSC2046_H_

#include <stm32f4xx.h>


void TSC2046_LowLevel_Init(void);
void TSC2046_Init(void);

#endif
